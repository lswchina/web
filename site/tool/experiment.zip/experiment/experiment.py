import spacy
import html
import openpyxl
import argparse
import os
import sys
import io
import re
from openpyxl import Workbook
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8')
PATH = os.path.abspath('.')
PATH1 = os.path.join(PATH, 'user')
PATH2 = os.path.join(PATH, 'vitas')
PATH3 = os.path.join(PATH, 'random')
PATH4 = os.path.join(PATH, 'skillExplorer')
BENCHMARK_FILE = os.path.join('benchmark.txt')

def splitSentence(Line):
    Line = toValidStr(Line)
    Line.replace(".&lt;Short audio&gt;.", "<Short audio>.")
    Lines = Line.split("<Short audio>.")
    clauses = []
    for line in Lines:
        nlp = spacy.load("en_core_web_sm")
        doc = nlp(line)
        clause = ""
        inQuotes = False
        tempclauses = []
        for i in range(len(doc)):
            if getTokenPos(doc[i]) == "PUNCT":
                if doc[i].text == '.' or doc[i].text == '!' or doc[i].text == '?':
                    if inQuotes == False:
                        if clause != "":
                            tempclauses.append(clause)
                            clause = ""
                    else:
                        clause = clause + doc[i].text
                elif '.' in doc[i].text  or '!' in doc[i].text or '?' in doc[i].text:
                    if '.' in doc[i].text:
                        position = str(doc[i].text).index('.')
                    elif '!' in doc[i].text:
                        position = str(doc[i].text).index('!')
                    else:
                        position = str(doc[i].text).index('?')
                    if clause == "":
                        clause = str(doc[i].text)[: position]
                    else:
                        clause = clause + " " + str(doc[i].text)[: position]
                    tempclauses.append(clause)
                    clause = str(doc[i].text)[position + 1:]
                elif doc[i].text == "\"":
                    if inQuotes == True:
                        inQuotes = False
                    else:
                        inQuotes = True
                    if clause == "":
                        clause = doc[i].text
                    else:
                        clause = clause + " " + doc[i].text
                else:
                    clause = clause + doc[i].text
            elif getTokenPos(doc[i]) != "SPACE":
                if clause != "":
                    clause = clause + " " + doc[i].text
                else:
                    if str(doc[i].text)[0] >= 'a' and str(doc[i].text)[0] <= 'z':
                        if len(tempclauses) > 0:
                            clause = tempclauses.pop()
                            clause = clause + " " + doc[i].text
                        else:
                            clause = clause + doc[i].text
                    else:
                        clause = clause + doc[i].text
        if clause != "":
            tempclauses.append(clause)
        tempclauses.append("<Short audio>")
        clauses.extend(tempclauses)
    if len(clauses) == 0:
        clauses.append(" ")
    else:
        clauses.pop()
    return clauses

def getTokenPos(token):
    if type(token) == spacy.tokens.span.Span:
        return token.root.pos_
    return token.pos_

def toValidStr(string):
    string = html.unescape(string)
    string = string.encode(encoding='utf-8', errors = 'ignore').decode(encoding='utf-8')
    string = string.replace("‘", '\'')
    string = string.replace("’", '\'')
    string = string.replace("”", '\"')
    string = string.replace("“", '\"')
    text = re.compile(u"[\s\w\.'!?,<>]").findall(string)
    string = "".join(text)
    return string

def coverage_user(path, skillname):
    state_space = []
    filename = skillname + '.txt'
    if not os.path.exists(os.path.join(path, filename)):
        return state_space
    with open(os.path.join(path, filename), 'r', encoding='utf-8') as skillFile:
        line1 = skillFile.readline()
        line = skillFile.readline()
        line = line.replace('\n', '')
        while line and '<--skill exit-->' not in line:
            answers = splitSentence(line)
            if (len(answers) != 1 or answers[0] != " ") and line != '':
                for ans in answers:
                    if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                        continue
                    else:
                        if ans not in state_space:
                            state_space.append(ans)
            line1 = skillFile.readline()
            if not line1:
                break
            line = skillFile.readline()
            line = line.replace('\n', '')
    return state_space

def coverage_vitas(path, skillname):
    state_space = []
    i = 0
    while True:
        filename = skillname + str(i) + '.txt'
        if not os.path.exists(os.path.join(path, filename)):
            break
        with open(os.path.join(path, filename), 'r', encoding='utf-8') as skillFile:
            line1 = skillFile.readline()
            line = skillFile.readline()
            line = line.replace('\n', '')
            while line and '<--skill exit-->' not in line:
                answers = splitSentence(line)
                if (len(answers) != 1 or answers[0] != " ") and line != '':
                    for ans in answers:
                        if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                            continue
                        else:
                            if ans not in state_space:
                                state_space.append(ans)
                line1 = skillFile.readline()
                if not line1:
                    break
                line = skillFile.readline()
                line = line.replace('\n', '')
        i = i + 1
    return state_space

def coverage_round_vitas(path, skillname):
    len_state_space = []
    state_space = []
    i = 0
    while True:
        filename = skillname + str(i) + '.txt'
        if not os.path.exists(os.path.join(path, filename)):
            break
        with open(os.path.join(path, filename), 'r', encoding='utf-8') as skillFile:
            line1 = skillFile.readline()
            line = skillFile.readline()
            line = line.replace('\n', '')
            while '<--skill exit-->' not in line:
                answers = splitSentence(line)
                if (len(answers) != 1 or answers[0] != " ") and line != '':
                    for ans in answers:
                        if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                            continue
                        else:
                            if ans not in state_space:
                                state_space.append(ans)
                len_state_space.append(len(state_space))
                line1 = skillFile.readline()
                if not line1:
                    break
                line = skillFile.readline()
                if not line:
                    break
                line = line.replace('\n', '')
        i = i + 1
    return len_state_space

def coverage_skillExplorer(path, skillname):
    state_space = []
    skillname = skillname.replace(':', ' ')
    skillname = skillname.replace('\'', ' ')
    DIR = os.path.join(path, skillname)
    index = 0
    k = 2
    if not os.path.exists(os.path.join(DIR, str(index))):
        return state_space
    while os.path.exists(os.path.join(DIR, str(index))) == True:
        ROUND_DIR = os.path.join(DIR, str(index))
        files = sorted(os.listdir(ROUND_DIR))
        for fileN in files:
            with open(os.path.join(ROUND_DIR, fileN), 'r', encoding='utf-8') as file:
                sign = file.readline()
                content = file.readline()
                while sign:
                    temp_add_space = []
                    if sign[0:2] == 'E:':
                        if '<---same content as before--->' in content:
                            pass
                        elif '<---nothing update--->' in content or '<---response is null--->' in content or '<---no answer--->' in content:
                            pass
                        elif '<---skill closed--->' in content or '<---exit skill--->' in content or '<---network error--->' in content:
                            break
                        else:
                            try:
                                body = re.findall(r'<---(.*?)--->(.*?)$', content)[0][1]
                            except:
                                body = content
                            answers = splitSentence(body)
                            if (len(answers) != 1 or answers[0] != " ") and body != '':
                                for ans in answers:
                                    if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                                        continue
                                    ans_no_blank = ans.strip()
                                    if ans_no_blank not in state_space and ans_no_blank != '' and ans_no_blank != '.':
                                        state_space.append(ans_no_blank)
                        k = k + 1
                    sign = file.readline()
                    if not sign:
                        break
                    content = file.readline()
        index = index + 1
    return state_space

def coverage_round_skillExplorer(path, skillname):
    len_state_space = []
    state_space = []
    skillname = skillname.replace(':', ' ')
    skillname = skillname.replace('\'', ' ')
    DIR = os.path.join(path, skillname)
    index = 0
    k = 2
    if not os.path.exists(os.path.join(DIR, str(index))):
        return len_state_space
    while os.path.exists(os.path.join(DIR, str(index))) == True:
        ROUND_DIR = os.path.join(DIR, str(index))
        files = sorted(os.listdir(ROUND_DIR))
        for fileN in files:
            with open(os.path.join(ROUND_DIR, fileN), 'r', encoding='utf-8') as file:
                sign = file.readline()
                content = file.readline()
                while sign:
                    if sign[0:2] == 'E:':
                        if '<---same content as before--->' in content:
                            pass
                        elif '<---nothing update--->' in content or '<---response is null--->' in content or '<---no answer--->' in content:
                            pass
                        elif '<---skill closed--->' in content or '<---exit skill--->' in content or '<---network error--->' in content:
                            break
                        else:
                            try:
                                body = re.findall(r'<---(.*?)--->(.*?)$', content)[0][1]
                            except:
                                body = content
                            answers = splitSentence(body)
                            if (len(answers) != 1 or answers[0] != " ") and body != '':
                                for ans in answers:
                                    if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                                        continue
                                    ans_no_blank = ans.strip()
                                    if ans_no_blank not in state_space and ans_no_blank != '' and ans_no_blank != '.':
                                        state_space.append(ans_no_blank)
                        len_state_space.append(len(state_space))
                        k = k + 1
                    sign = file.readline()
                    if not sign:
                        break
                    content = file.readline()
        index = index + 1
    return len_state_space

def get_percentage(len_state_space, min_value):
    percentage = []
    for index in range(len(len_state_space)):
        percentage.append(round(len_state_space[index] / min_value, 1))
    return percentage

def get_coverage_round(percentage):
    coverage_round = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    last_col = 0
    for j, per in enumerate(percentage):
        col = int(per * 10)
        val = j + 1
        for real_col in range(last_col, min(col, 10)):
            coverage_round[real_col] = val
        if col >= 10:
            break
        last_col = col
    return coverage_round

def get_coverage_vitas_random(EXCEL_NAME):
    book = openpyxl.Workbook(EXCEL_NAME)
    book.create_sheet(index = 0, title = "benchmark vs random")
    book.create_sheet(index = 1, title = "other skill")
    book.save(EXCEL_NAME)
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book["benchmark vs random"]
    sheet2 = book["other skill"]
    title = ['skill\'s name', 'vitas', 'random', 'percentage']
    for i, tit in enumerate(title):
        sheet.cell(row = 1, column = i + 1, value = tit)
        sheet2.cell(row = 1, column = i + 1, value = tit)
    with open(BENCHMARK_FILE, 'r', encoding='utf-8') as file:
        skillname = file.readline()
        index = 2
        index2 = 2
        while skillname:
            usable = True
            skillname = skillname.strip()
            result = [skillname]
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_state_space = coverage_vitas(PATH2, filename)
            random_state_space = coverage_vitas(PATH3, filename)
            if len(vitas_state_space) == 0:
                result.append('unavailable')
                usable = False
            else:
                result.append(len(vitas_state_space))
            if len(random_state_space) == 0:
                result.append('unavailable')
                usable = False
            else:
                result.append(len(random_state_space))
            if len(vitas_state_space) > 0 and len(random_state_space) > 0 and len(list(set(vitas_state_space) & set(random_state_space))) == 0:
                result[1] = 'inconsistent behavior'
                result[2] = 'inconsistent behavior'
                usable = False
            if usable == False:
                result.append("N/A")
            else:
                result.append((len(vitas_state_space) - len(random_state_space)) / len(random_state_space))
            if usable == True:
                for i, res in enumerate(result):
                    sheet.cell(row = index, column = i + 1, value = res)
                index = index + 1
            else:
                for i, res in enumerate(result):
                    sheet2.cell(row = index2, column = i + 1, value = res)
                index2 = index2 + 1
            skillname = file.readline()
            book.save(EXCEL_NAME)

def get_coverage_vitas_skillExplorer(EXCEL_NAME):
    book = openpyxl.Workbook(EXCEL_NAME)
    book.create_sheet(index = 0, title = "benchmark vs skillExplorer")
    book.create_sheet(index = 1, title = "other skill")
    book.save(EXCEL_NAME)
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book["benchmark vs skillExplorer"]
    sheet2 = book["other skill"]
    title = ['skill\'s name', 'vitas', 'skillExplorer', 'percentage']
    for i, tit in enumerate(title):
        sheet.cell(row = 1, column = i + 1, value = tit)
        sheet2.cell(row = 1, column = i + 1, value = tit)
    with open(BENCHMARK_FILE, 'r', encoding='utf-8') as file:
        skillname = file.readline()
        index = 2
        index2 = 2
        while skillname:
            usable = True
            skillname = skillname.strip()
            result = [skillname]
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_state_space = coverage_vitas(PATH2, filename)
            ex_state_space = coverage_skillExplorer(PATH4, skillname)
            if len(vitas_state_space) == 0:
                result.append('unavailable')
                usable = False
            else:
                result.append(len(vitas_state_space))
            if len(ex_state_space) == 0:
                result.append('unavailable')
                usable = False
            else:
                result.append(len(ex_state_space))
            if len(vitas_state_space) > 0 and len(ex_state_space) > 0 and len(list(set(vitas_state_space) & set(ex_state_space))) == 0:
                result[1] = 'inconsistent behavior'
                result[2] = 'inconsistent behavior'
                usable = False
            if usable == False:
                result.append("N/A")
            else:
                result.append((len(vitas_state_space) - len(ex_state_space)) / len(ex_state_space))
            if usable == True:
                for i, res in enumerate(result):
                    sheet.cell(row = index, column = i + 1, value = res)
                index = index + 1
            else:
                for i, res in enumerate(result):
                    sheet2.cell(row = index2, column = i + 1, value = res)
                index2 = index2 + 1
            skillname = file.readline()
            book.save(EXCEL_NAME)

def get_coverage_four(EXCEL_NAME):
    book = openpyxl.Workbook(EXCEL_NAME)
    book.create_sheet("coverage & rate", 0)
    book.create_sheet("other skill", 1)
    book.save(EXCEL_NAME)
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book["coverage & rate"]
    sheet2 = book["other skill"]
    title = ['skill\'s name', 'user', 'vitas', 'random', 'skillExplorer', 'union']
    for i, tit in enumerate(title):
        sheet.cell(row = 1, column = i + 1, value = tit)
        sheet2.cell(row = 1, column = i + 1, value = tit)
    with open(BENCHMARK_FILE, 'r', encoding='utf-8') as file:
        skillname = file.readline()
        index = 2
        index2 = 2
        while skillname:
            usable = True
            skillname = skillname.strip()
            filename = re.sub(r'(\W+)', '_', skillname)
            result = [skillname]
            user_state_space = coverage_user(PATH1, filename)
            vitas_state_space = coverage_vitas(PATH2, filename)
            random_state_space = coverage_vitas(PATH3, filename)
            ex_state_space = coverage_skillExplorer(PATH4, skillname)
            if len(user_state_space) == 0:
                result.append('unavailable')
                usable = False
            else:
                result.append(str(len(user_state_space)))
            if len(vitas_state_space) == 0:
                result.append('unavailable')
                usable = False
            elif len(user_state_space) != 0 and len(list(set(vitas_state_space) & set(user_state_space))) == 0:
                result.append('inconsistent behavior')
                vitas_state_space = []
                usable = False
            else:
                result.append(str(len(vitas_state_space)))
            if len(random_state_space) == 0:
                result.append('unavailable')
                usable = False
            elif len(user_state_space) != 0 and len(list(set(random_state_space) & set(user_state_space))) == 0:
                result.append('inconsistent behavior')
                random_state_space = []
                usable = False
            else:
                result.append(str(len(random_state_space)))
            if len(ex_state_space) == 0:
                result.append('unavailable')
                usable = False
            elif len(user_state_space) != 0 and len(list(set(ex_state_space) & set(user_state_space))) == 0:
                result.append('inconsistent behavior')
                ex_state_space = []
                usable = False
            else:
                result.append(str(len(ex_state_space)))
            all_state1 = list(set(vitas_state_space) | set(user_state_space))
            all_state2 = list(set(ex_state_space) | set(random_state_space))
            all_state = list(set(all_state1) | set(all_state2))
            result.append(len(all_state))
            if usable == True:
                for i, res in enumerate(result):
                    sheet.cell(row=index, column = i + 1, value = res)
                index = index + 1
            else:
                for i, res in enumerate(result):
                    sheet2.cell(row=index2, column = i + 1, value = res)
                index2 = index2 + 1
            book.save(EXCEL_NAME)
            skillname = file.readline()

def get_coverage_round_vitas_random(EXCEL_NAME):
    book = openpyxl.Workbook(EXCEL_NAME)
    book.create_sheet(index = 0, title = 'vitas')
    book.create_sheet(index = 1, title = 'random')
    book.create_sheet(index = 2, title = 'other skill')
    book.save(EXCEL_NAME)
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book['vitas']
    sheet2 = book['random']
    sheet3 = book['other skill']
    title = ['skill\'s name', '10%', '20%', '30%', '40%', '50%', '60%', '70%', '80%', '90%', '100%']
    for i, tit in enumerate(title):
        sheet.cell(row = 1, column = i + 1, value = tit)
        sheet2.cell(row = 1, column = i + 1, value = tit)
    with open(BENCHMARK_FILE, 'r', encoding='utf-8') as file:
        skillname = file.readline()
        index = 2
        index2 = 2
        while skillname:
            skillname = skillname.strip()
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_len_state_space = coverage_round_vitas(PATH2, filename)
            random_len_state_space = coverage_round_vitas(PATH3, filename)
            if len(vitas_len_state_space) == 0 or len(random_len_state_space) == 0:
                sheet3.cell(row = index2, column = 1, value = skillname)
                sheet3.cell(row = index2, column = 2, value = 'unavailable')
                index2 = index2 + 1
            else:
                min_state_space = min(vitas_len_state_space[-1], random_len_state_space[-1])
                vitas_percentage = get_percentage(vitas_len_state_space, min_state_space)
                random_percentage = get_percentage(random_len_state_space, min_state_space)
                if vitas_percentage[-1] > 1.2 or random_percentage[-1] > 1.2:
                    sheet3.cell(row = index2, column = 1, value = skillname)
                    sheet3.cell(row = index2, column = 2, value = max(vitas_percentage[-1], random_percentage[-1]))
                    index2 = index2 + 1
                else:
                    vitas_round = get_coverage_round(vitas_percentage)
                    random_round = get_coverage_round(random_percentage)
                    sheet.cell(row = index, column = 1, value = skillname)
                    sheet2.cell(row = index, column = 1, value = skillname)
                    for col in range(len(vitas_round)):
                        sheet.cell(row = index, column = col + 2, value = vitas_round[col])
                        sheet2.cell(row = index, column = col + 2, value = random_round[col])
                    index = index + 1
            skillname = file.readline()
            book.save(EXCEL_NAME)

def get_coverage_round_vitas_skillExplorer(EXCEL_NAME):
    book = openpyxl.Workbook(EXCEL_NAME)
    book.create_sheet(index = 0, title = 'vitas')
    book.create_sheet(index = 1, title = 'skillExplorer')
    book.create_sheet(index = 2, title = 'other skill')
    book.save(EXCEL_NAME)
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book['vitas']
    sheet2 = book['skillExplorer']
    sheet3 = book['other skill']
    title = ['skill\'s name', '10%', '20%', '30%', '40%', '50%', '60%', '70%', '80%', '90%', '100%']
    for i, tit in enumerate(title):
        sheet.cell(row = 1, column = i + 1, value = tit)
        sheet2.cell(row = 1, column = i + 1, value = tit)
    with open(BENCHMARK_FILE, 'r', encoding='utf-8') as file:
        skillname = file.readline()
        index = 2
        index2 = 2
        while skillname:
            skillname = skillname.strip()
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_len_state_space = coverage_round_vitas(PATH2, filename)
            ex_len_state_space = coverage_round_skillExplorer(PATH4, skillname)
            if len(vitas_len_state_space) == 0 or len(ex_len_state_space) == 0:
                sheet3.cell(row = index2, column = 1, value = skillname)
                sheet3.cell(row = index2, column = 2, value = 'unavailable')
                index2 = index2 + 1
            else:
                min_state_space = min(vitas_len_state_space[-1], ex_len_state_space[-1])
                vitas_percentage = get_percentage(vitas_len_state_space, min_state_space)
                ex_percentage = get_percentage(ex_len_state_space, min_state_space)
                if vitas_percentage[-1] > 1.2 or ex_percentage[-1] > 1.2:
                    sheet3.cell(row = index2, column = 1, value = skillname)
                    sheet3.cell(row = index2, column = 2, value = max(vitas_percentage[-1], ex_percentage[-1]))
                    index2 = index2 + 1
                else:
                    vitas_round = get_coverage_round(vitas_percentage)
                    ex_round = get_coverage_round(ex_percentage)
                    sheet.cell(row = index, column = 1, value = skillname)
                    sheet2.cell(row = index, column = 1, value = skillname)
                    for col in range(len(vitas_round)):
                        sheet.cell(row = index, column = col + 2, value = vitas_round[col])
                        sheet2.cell(row = index, column = col + 2, value = ex_round[col])
                    index = index + 1
            skillname = file.readline()
            book.save(EXCEL_NAME)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("figure", help="enter the number of figure", action = "store")
    args = parser.parse_args()
    if args.figure == '5':
        get_coverage_vitas_random('fig5_coverage_vitas_vs_random.xlsx')
    elif args.figure == '6':
        get_coverage_vitas_skillExplorer('fig6_coverage_vitas_vs_skillExplorer.xlsx')
    elif args.figure == '7':
        get_coverage_four('fig7_coverage_rate_four.xlsx')
    elif args.figure == '8':
        get_coverage_round_vitas_random('fig8_coverage_round_vitas_vs_random.xlsx')
    elif args.figure == '9':
        get_coverage_round_vitas_skillExplorer('fig9_coverage_round_vitas_vs_skillExplorer.xlsx')
    else:
        print('invalid figure number')

if __name__ == '__main__':
    main()
