import re
import spacy
import sys
import random
import time
import Step2_1_NLPAnalysis as nlp_als
import Step2_2_TF_IDF as tf_idf
from copy import deepcopy
import itertools
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

ALPHA = 0.6
BETA = 0.4
GAMMA = 1.0 / nlp_als.M

PATH_DIC = {
    'justchat': '//*[@id="pb-message-container"]/div/div[3]/div/button[3]',
    'accept': '//*[@id="pb-message-container"]/div[3]/div[3]/div/button[1]',
    'inputplace': '//*[@id="main-input"]/input', 
    'answerbegin': '//*[@id="pb-message-container"]/div[',
    'answerend': ']/div/div/div'
}

KEY_LIST = ['number', 'year', 'month', 'day', 'date', 'score', 'animal', 'capital', 'language', 'food', 'stock', 'fruit', 'country', 'name', 'gender', 'job', 'color']
KNOWLEDGE_LIST = [
    ['0', '1', '2', '3', '20', '50'],
    ['1990', '2000', '2010', '2020'],
    ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'September'],
    ['today', 'yesterday', 'twenty-nineth of March', 'May the first'],
    ['today', 'yesterday', 'twenty-nineth of March', 'May the first'],
    ['1.0', '5.0', '3.0', '10.0', '100.0'],
    ['rat', 'cow', 'tiger', 'rabbit', 'dragon', 'snake', 'horse', 'sheep', 'monkey', 'chicken', 'dog', 'pig', 'elephant', 'cat', 'lion'],
    ['Beijing', 'Tokyo', 'Washington DC', 'Seoul', 'Canberra', 'Berlin', 'Paris'],
    ['English', 'Chinese', 'Spanish', 'Japanese', 'German', 'Korean', 'French'],
    ['salad', 'roast chicken', 'fried potato', 'pizza', 'spaghetti'],
    ['Microsoft', 'Facebook', 'Wal-Mart', 'Ford', 'Mitsubishi', 'Sony', 'Tencent'],
    ['apple', 'pear', 'orange', 'banana', 'peach', 'pineapple', 'watermelon', 'cherry', 'durian'],
    ['China', 'Japan', 'America', 'Keorea', 'Australia', 'Germany', 'England', 'France'],
    ['Lisa', 'Lily', 'Bob', 'Harry'],
    ['female', 'male'],
    ['teacher', 'doctor'],
    ['red', 'orange', 'yellow', 'green', 'blue', 'violet', 'white', 'black']
]

NUMBER_LIST = ['much', 'many']
KNOW_LIST = ['1', '2', '3', '4', '5']

class getAns:
    def __init__(self, basicComds, sysComds, skillFuncs, web_driver):
        self.timeStart = time.time()
        self.basicAns = basicComds
        self.sysAns = sysComds
        self.helpAns = {}
        self.skillFu = skillFuncs
        self.AnswerDict = {}
        self.driver = web_driver
        try:
            self.driver.refresh()
            time.sleep(2)
            self.driver.find_element_by_xpath(get_ans.PATH_DIC['justchat']).click()
            time.sleep(1)
            self.driver.find_element_by_xpath(get_ans.PATH_DIC['accept']).click()
            time.sleep(2)
        except:
            pass
        
    def imergeNones(self, question):
        self.question = question
        self.spacyRet = []
        nlp = spacy.load("en_core_web_sm")
        doc = nlp(question)
        for word in doc:
            self.spacyRet.append(word)
        for chunk in doc.noun_chunks:
            words = chunk.text.replace(" ", "")
            begin = 0
            isEqual = False
            words_left = -1
            words_right = -1
            for j in range(len(self.spacyRet)):
                length = len(self.spacyRet[j].text)
                if begin + length > len(words):
                    words_right = j
                    break
                elif self.spacyRet[j].text == words[begin: begin + length]:
                    if isEqual == False:
                        words_left = j
                        isEqual = True
                    begin = begin + length
                else:
                    isEqual = False
                    begin = 0
                    words_left = -1
                    words_right = -1
            if words_left >= 0:
                if words_right == -1:
                    words_right = len(self.spacyRet)
                del self.spacyRet[words_left: words_right]
                self.spacyRet.insert(words_left, chunk)
    
    def getSQAns(self):
        self.sQAns = []
        remove_list = ["say", "ask", "tell", "give", "choose", "pick"]
        Ans = set()
        for word in reversed(self.spacyRet):
            if nlp_als.getTokenDep(word) == "conj":
                if word.text not in remove_list:
                    Ans.add(word.text)
                if nlp_als.getTokenPos(nlp_als.getTokenHead(word)) == nlp_als.getTokenPos(word):
                    current = word
                    while nlp_als.getTokenPos(nlp_als.getTokenHead(current)) == nlp_als.getTokenPos(current) and nlp_als.getTokenDep(nlp_als.getTokenHead(current)) == 'conj':
                        next_phrase = ''
                        for phrase in self.spacyRet:
                            if nlp_als.getTokenHead(current).text in phrase.text:
                                next_phrase = phrase.text
                                break
                        if next_phrase in Ans or next_phrase in remove_list:
                            break
                        Ans.add(next_phrase)
                        current = nlp_als.getTokenHead(current)
        for ans in Ans:
            answer = re.sub(r"[^\sa-zA-Z0-9_\.,?!]", '', ans)
            temp = re.sub(r"[^a-zA-Z]", '', answer)
            if temp != 'Alexa' and temp != 'alexa':
                self.sQAns.append(answer)
        return self.sQAns

    def getIQAns(self):
        self.iQAns = []
        instruction_list = ['say', 'ask', 'tell']
        first_parse_result = []
        isInsQ = False
        intruction_words = []
        instr_w = ""
        for word in self.spacyRet:
            if isInsQ == False:
                if word.lemma_ in instruction_list:
                    isInsQ = True
                    intruction_words = [word]
                    instr_w = word.lemma_
            else:
                if word.lemma_ in instruction_list and (word.lemma_ != 'tell' or intruction_words[0].lemma_ == 'tell'):
                    if instr_w != "" and instr_w not in instruction_list:
                        instr_w = re.sub(r"[^\sa-zA-Z0-9_\.,?!]", '', instr_w)
                        temp = re.sub(r"[^a-zA-Z]", '', instr_w)
                        if temp.lower() != 'sayalexa' and temp.lower() != 'askalexa' and temp.lower() != 'tellalexa':
                            first_parse_result.append(intruction_words)
                    intruction_words = [word]
                    instr_w = word.lemma_
                else:
                    if nlp_als.getTokenPos(word) == "PUNCT" or word.lemma_ == "or" or word.lemma_ == "and":
                        if word.text != "." and word.text != "?" and word.text != "!":
                            if word.text != "'" and word.text != '"' and word.text != ":" and instr_w != "" and instr_w not in instruction_list:
                                instr_w = re.sub(r"[^\sa-zA-Z0-9_\.,?!]", '', instr_w)
                                temp = re.sub(r"[^a-zA-Z]", '', instr_w)
                                if temp.lower() != 'sayalexa' and temp.lower() != 'askalexa' and temp.lower() != 'tellalexa':
                                    first_parse_result.append(intruction_words)
                                intruction_words = [intruction_words[0]]
                                instr_w = intruction_words[0].lemma_
                        else:
                            isInsQ = False
                    else:
                        intruction_words.append(word)
                        instr_w = instr_w + " " + word.text
        if instr_w != "" and instr_w not in instruction_list:
            instr_w = re.sub(r"[^\sa-zA-Z0-9_\.,?!]", '', instr_w)
            temp = re.sub(r"[^a-zA-Z]", '', instr_w)
            if temp.lower() != 'sayalexa' and temp.lower() != 'askalexa' and temp.lower() != 'tellalexa':
                first_parse_result.append(intruction_words)
        for sentence in first_parse_result:
            if sentence[0].lemma_ == "ask":
                ans = self.getAskAns(sentence)
                if ans != "":
                    self.iQAns.append(ans)
            elif sentence[0].lemma_ == "say":
                ans = self.getSayAns(sentence)
                if ans != "":
                    self.iQAns.append(ans)
            else:
                self.iQAns.extend(self.getTellAns(sentence))
        return self.iQAns

    def getAskAns(self, ask_sentence):
        wh_list = ["what", "when", "where", "who", "whom", "whose", "why", "how"]
        prep_list = ["to", "for", "about", "like"]
        Ans = ""
        if ask_sentence[1].text.lower() == "that":
            if len(ask_sentence) <= 3:
                return Ans
            Ans = ask_sentence[2].text
            for i in range(3, len(ask_sentence)):
                Ans = Ans + " " + ask_sentence[i].text
        else:
            isInstr = False
            for i in range(1, len(ask_sentence)):
                if isInstr == False:
                    if ask_sentence[i].lemma_ in prep_list:
                        isInstr = True
                    if ask_sentence[i].text.lower() in wh_list:
                        isInstr = True
                        Ans = ask_sentence[i].text
                else:
                    if Ans == "":
                        Ans = ask_sentence[i].text
                    else:
                        Ans = Ans + " " + ask_sentence[i].text
        if Ans == "":
            Ans = ask_sentence[1].text
            for i in range(2, len(ask_sentence)):
                Ans = Ans + " " + ask_sentence[i].text
        return Ans

    def getSayAns(self, ask_sentence):
        wh_list = ["what", "when", "where", "who", "whom", "whose", "why", "how"]
        prep_list = ["to", "for"]
        Ans = ""
        if ask_sentence[1].text.lower() in wh_list:
            Ans = ask_sentence[1].text
            for i in range(2, len(ask_sentence)):
                Ans = Ans + " " + ask_sentence[i].text
        elif ask_sentence[1].text.lower() == "that":
            if len(ask_sentence) <= 3:
                return Ans
            Ans = ask_sentence[2].text
            for i in range(3, len(ask_sentence)):
                Ans = Ans + " " + ask_sentence[i].text
        else:
            isLike = False
            for i in range(1, len(ask_sentence)):
                if isLike == False:
                    if ask_sentence[i].lemma_ == "like":
                        isLike = True
                else:
                    if Ans == "":
                        Ans = ask_sentence[i].text
                    else:
                        Ans = Ans + " " + ask_sentence[i].text
            if isLike == True and Ans != "":
                return Ans
            Ans = ask_sentence[1].text
            for i in range(2, len(ask_sentence)):
                if ask_sentence[i].lemma_ in prep_list:
                    return Ans
                Ans = Ans + " " + ask_sentence[i].text
        return Ans

    def getTellAns(self, tell_sentence):
        Ans = []
        if tell_sentence[1].text.lower() != 'me' or len(tell_sentence) <= 2:
            return Ans
        for word in tell_sentence[2:]:
            for i, KEY in enumerate(KEY_LIST):
                if KEY in word.text.lower():
                    Ans = KNOWLEDGE_LIST[i]
                    break
            if len(Ans) > 0:
                break
        print(tell_sentence)
        if len(Ans) == 0 and len(tell_sentence) >= 3:
            if 'how many' in tell_sentence[2].text.lower() or 'how much' in tell_sentence[2].text.lower():
                Ans = KNOW_LIST
        return Ans

    def getYNAns(self):
        self.yNQAns = []
        index = 0
        is_Aux = False
        for i, word in enumerate(self.spacyRet):
            if index == 0:
                if nlp_als.getTokenDep(word) == "aux" or nlp_als.getTokenPos(word) == "AUX":
                    is_Aux = True
                index = 1
                continue
            if index == 1 and is_Aux == True:
                if nlp_als.getTokenDep(word) == "nsubj" or nlp_als.getTokenDep(word) == "attr" or word.text == 'you':
                    self.yNQAns.append("Yes")
                    self.yNQAns.append("No")
                    self.yNQAns.append('I do not know')
                    break
            if nlp_als.getTokenPos(word) == 'PUNCT' and word.text == ',':
                index = 0
                is_Aux = False
                continue
            index = index + 1
        return self.yNQAns

    def isWhQ(self, question):
        self.OQAns = []
        instr_list = ["say", "ask", "tell", "give"]
        for word in instr_list:
            if word in question:
                return False
        Answers = {
            "What": [''],
            "what": [''],
            "When": ['Today', 'At 2pm'],
            "when": ['Today', 'At 2pm'],
            "Where": ['China', 'In the supermarket'],
            "where": ['China', 'In the supermarket'],
            "Who": ['Taylor Swift', 'Tagore'],
            "who": ['Taylor Swift', 'Tagore'],
            "Whom": ['Taylor Swift', 'Tagore'],
            "whom": ['Taylor Swift', 'Tagore'],
            "Whose": ['Mine', 'Adele\'s'],
            "whose": ['Mine', 'Adele\'s'],
            "Why": [''],
            "why": [''],
            "How": [''],
            "how": ['']
        }
        clauses = question.split(",")
        beginWord = ''
        for clause in clauses:
            words = clause.split(" ")
            for word in words:
                if word != '':
                    beginWord = word
                    break
            self.OQAns = Answers.get(beginWord, [])
            if len(self.OQAns) > 0:
                return True
        return False
    
    def getWhQAns(self):
        #is wh question or mixed question
        if self.isWhQ(self.question) == True:
            if len(self.OQAns) == 1:
                clauses = self.question.split(",")
                for clause in clauses:
                    words = clause.split(" ")
                    for word in words:
                        if word == 'What' or word == 'what':
                            self.OQAns = self.getWhatAns(clause)
                        elif word == 'How' or word == 'how':
                            self.OQAns = self.getHowAns(clause)
                        else:
                            pass
                        break
                    if len(self.OQAns) > 1:
                        break
                if len(self.OQAns) == 1:
                    answer = self.askMisuku()
                    if answer == '':
                        answer = "I do not know"
                    else:
                        answer = re.sub(r"[^\sa-zA-Z0-9_\.,?!]", '', answer)
                    self.OQAns = [answer]
        return self.OQAns

    def getWhatAns(self, question):
        Key = []
        nlp = spacy.load("en_core_web_sm")
        doc = nlp(question)
        for chunk in doc.noun_chunks:
            if chunk.text == 'What' or chunk.text == 'what' or chunk.text == 'you':
                continue
            if 'what' in chunk.text or 'What' in chunk.text:
                Key.append(chunk.text[5:].lower())
            else:
                Key.append(chunk.text.lower())
        for word in doc:
            if word.pos_ == "NOUN" or word.pos_ == 'PROPN':
                exist = False
                for key in Key:
                    if word.text.lower() in key:
                        exist = True
                        break
                if exist == False:
                    Key.append(word.text.lower())
        index = -1
        for key in Key:
            for i, KEY in enumerate(KEY_LIST):
                if KEY in key:
                    index = i
                    break
            if index != -1:
                break
        response_remove = []
        for ans in self.response:
            for KEY in KEY_LIST:
                if KEY in ans.lower():
                    response_remove.append(ans)
                    break
        for ans in response_remove:
            self.response.pop(ans)
        if index == -1:
            return ['']
        return KNOWLEDGE_LIST[index]

    def getHowAns(self, question):
        words = question.split(" ")
        if len(words) > 1 and words[1] in NUMBER_LIST:
            return KNOW_LIST
        return ['']

    def askMisuku(self):
        try:
            self.last_ans = self.driver.find_element_by_xpath(PATH_DIC['answerbegin'] + '1' + PATH_DIC['answerend']).get_attribute('innerHTML').replace('<br>', ' ')[:250]
            ai = self.driver.find_element_by_xpath(PATH_DIC['inputplace'])
            unrespondingtime = 0
            result = ''
            while True and unrespondingtime < 5:
                # inputs the listen variable into the bot
                ai.send_keys(self.question)
                ai.send_keys(Keys.ENTER)
                time.sleep(2)
            #checks to see if mitsuku gave a response; goes back to start of loop if not
                while True:
                    try:
                        for b in itertools.count(start = 3, step = 2):
                            self.driver.find_element_by_xpath(PATH_DIC['answerbegin'] + str(b) + PATH_DIC['answerend'])
                    except:
                        b = b - 2
                        #print(self.driver.page_source)
                    botresponse = self.driver.find_element_by_xpath(PATH_DIC['answerbegin'] + str(b) + PATH_DIC['answerend']).get_attribute('innerHTML').replace('<br>', ' ')[:250]
                    if botresponse == self.last_ans:
                        #print("not_response: %r" %botresponse)
                        time.sleep(.5)
                        unrespondingtime += 0.5
                    else:
                        self.last_ans = botresponse
                        botresponse = botresponse.replace("\u200e", "")
                        nlp = spacy.load("en_core_web_sm")
                        doc = nlp(botresponse)
                        for word in doc:
                            if word.pos_ != "SPACE" and (word.pos_ != "PUNCT" or word.text == "'"):
                                if result != '':
                                    result = result + ' ' + word.text
                                else:
                                    result = word.text
                        print("mitsuku response: %r" %result)
                        return result
            return result
        except:
            return ''

    def getResponses(self, question):
        self.imergeNones(question)
        self.response = {}
        self.getIQAns()
        self.getSQAns()
        self.getYNAns()
        for Ans in self.yNQAns:
            res = [nlp_als.M, 0, 1.0]
            self.response[Ans] = res
        for Ans in self.iQAns:
            res = [nlp_als.M, 0, 1.0]
            self.response[Ans] = res
        for Ans in self.sQAns:
            res = [nlp_als.M, 0, 1.0]
            self.response[Ans] = res
        if self.isWhQ(self.question):
            self.getWhQAns()
            if len(self.OQAns) == 1:
                Ans = self.OQAns[0]
                res = [nlp_als.M, 0, 0.5]
                self.response[Ans] = res
            else:
                for Ans in self.OQAns:
                    res = [nlp_als.M, 0, 1.0]
                    self.response[Ans] = res
        return self.response

    def getResponse(self, questions, lastq, typeid, answer):
        if typeid != -1:
            if typeid == 3:
                Ce = self.helpAns[answer][1]
            else:
                Ce = self.AnswerDict[lastq][typeid][answer][1]
            newState = True
            old_state_num = 0
            for question in questions:
                if self.AnswerDict.get(question, None) != None:
                    old_state_num = old_state_num + 1
                    newState = False
            if newState == True:
                Ce = Ce + 0.1
                for question in questions:
                    if self.matchFuncs(question):
                        Ce = Ce + 0.1
                        break
            else:
                if lastq in questions:
                    Ce = Ce - 0.3
                else:
                    if len(questions) <= 2 * old_state_num:
                        Ce = Ce - 0.2
                    elif len(questions) <= 3 * old_state_num:
                        Ce = Ce - 0.1
                    else:
                        pass
            #the same state, change Ce to 0.0
            if typeid == 0:     #basicAns
                anstype = 0.8
            elif typeid == 1:   #sysAns
                anstype = 0.4
            else:               #generateAns
                anstype = 1.0
            if typeid == 3:
                self.helpAns[answer][1] = Ce
                self.helpAns[answer][2] = (ALPHA * anstype + BETA * self.helpAns[answer][1]) / (GAMMA * self.helpAns[answer][0])
            else:
                self.AnswerDict[lastq][typeid][answer][1] = Ce
                self.AnswerDict[lastq][typeid][answer][2] = (ALPHA * anstype + BETA * self.AnswerDict[lastq][typeid][answer][1]) / (GAMMA * self.AnswerDict[lastq][typeid][answer][0])
        
        #find the question to answer and store in ques
        ques = ''
        question_list = {}
        wh_question_list = {}
        coAnswers = []
        for question in reversed(questions):
            if self.isWhQ(question) == False:
                self.getResponses(question)
                if len(self.response) != 0: #question except wh-question
                    if len(question_list) == 0:
                        question_list[question] = 5
                    elif len(question_list) == 1:
                        question_list[question] = 3
                    else:
                        question_list[question] = 1
                    if self.AnswerDict.get(question, None) == None:
                        basic_ans = deepcopy(self.basicAns)
                        sys_ans = deepcopy(self.sysAns)
                        self.AnswerDict[question] = [basic_ans, sys_ans, self.response]
            else:#wh-question
                if len(question_list) == 0:
                    wh_question_list[question] = 5
                elif len(question_list) == 1:
                    wh_question_list[question] = 3
                else:
                    wh_question_list[question] = 1
        if len(question_list) != 0:
            total = sum(question_list.values())
            ra = random.randint(1, total)
            cur_to = 0
            for k in question_list:
                cur_to = cur_to + question_list[k]
                if cur_to >= ra:
                    ques = k
                    break
        elif len(wh_question_list) != 0:
            total = sum(wh_question_list.values())
            ra = random.randint(1, total)
            cur_to = 0
            for k in wh_question_list:
                cur_to = cur_to + wh_question_list[k]
                if cur_to >= ra:
                    ques = k
                    break
            if self.AnswerDict.get(ques, None) == None:
                self.getResponses(ques)
                basic_ans = deepcopy(self.basicAns)
                sys_ans = deepcopy(self.sysAns)
                self.AnswerDict[ques] = [basic_ans, sys_ans, self.response]
        else:
            if len(questions) > 0:
                ques = questions[-1]
            else:
                ques = '.'
            if self.AnswerDict.get(ques, None) == None:
                basic_ans = deepcopy(self.basicAns)
                sys_ans = deepcopy(self.sysAns)
                self.AnswerDict[ques] = [basic_ans, sys_ans, {}]
        coAnswers = self.AnswerDict[ques]

        #get ans with the highest weight
        maxWeit = 0
        typeInd = -1
        ans = ''
        for ind in range(len(coAnswers) - 1, -1, -1):
            for (k,v) in coAnswers[ind].items():  #v: [Fe, weight], k: answer
                if v[2] > maxWeit:
                    maxWeit = v[2]
                    typeInd = ind
                    ans = k
        for (k, v) in self.helpAns.items():
            if v[2] > maxWeit:
                maxWeit = v[2]
                typeInd = 3
                ans = k
        for Ans in self.helpAns:
            self.helpAns[Ans][2] = (ALPHA * 1.0 + BETA * self.helpAns[Ans][1]) / (GAMMA * self.helpAns[Ans][0])
        if typeInd == 3:
            self.helpAns[ans][0] = self.helpAns[ans][0] + 1
            if len(questions) > 0:
                return [typeInd, ans, questions[-1]]
            else:
                return [typeInd, ans, '.']
        ansType = 0.0
        for ind in range(len(coAnswers) - 1, -1, -1):
            if ind == 0:        #basicAns
                ansType = 0.8
            elif ind == 1:      #sysAns
                ansType = 0.4
            else:               #generate ans
                ansType = 1.0   
            for (k,v) in coAnswers[ind].items(): 
                if ind == typeInd and k == ans:
                    self.AnswerDict[ques][typeInd][ans][0] = self.AnswerDict[ques][typeInd][ans][0] + 1
                elif ind == 1: #sysAns
                    if self.AnswerDict[ques][ind][k][0] > 1:
                        self.AnswerDict[ques][ind][k][0] = self.AnswerDict[ques][ind][k][0] - 1
                self.AnswerDict[ques][ind][k][2] = (ALPHA * ansType + BETA * self.AnswerDict[ques][ind][k][1]) / (GAMMA * self.AnswerDict[ques][ind][k][0])
        #print(ans)
        return [typeInd, ans, ques]

    def addHelpAns(self, questions):
        for question in questions:
            self.imergeNones(question)
            self.getIQAns()
            self.getSQAns()
            res = [nlp_als.M, 0, 0.9]
            for Ans in self.iQAns:
                self.helpAns[Ans] = deepcopy(res)
            for Ans in self.sQAns:
                self.helpAns[Ans] = deepcopy(res)
        return

    def getHelpResponse(self, questions):
        self.addHelpAns(questions)
        return self.getResponse(questions, '', -1, 'Help')

    def matchFuncs(self, question):
        count = tf_idf.get_count(question)
        for key in count:
            for skillf in self.skillFu:
                if key in skillf:
                    print("%r matches!\n" %key)
                    return True
        return False

    def printt(self):
        for i, word in enumerate(self.spacyRet):
            print(word.text, nlp_als.getTokenPos(word), nlp_als.getTokenDep(word), nlp_als.getTokenHead(word))
