import requests
import re
import random
import html
import Step2_1_NLPAnalysis as nlp_als

WEB = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
USER_AGENT = {'User-Agent':WEB,'Host':'www.amazon.com'}

RE_DIC = {
    'alert': f'<div class="a-alert-content">(.*?)</div>',
    'title': f'<h1 class="a2s-title-content">\n\t\t(.*?)\n\t',
    'description': '<h2>Description</h2><span>(.*?)</span>',
    'invocation': f'''<span class="a-list-item">
        Invocation Name:
        <span class="a-text-bold">(.*?)</span>''',
    'permissions': f'<li class="a2s-permissions-list-item">(.*?)</li>',
    'perm': f'''<span class="a-list-item">
        
        
        
        
        (.*?)
    
    
    </span>''',
    'tit': f'<title>(.*?)</title>'
}

def getSkillWeb(SKILL_URL):
    sk_resp, sk_status = getURL(SKILL_URL)
    if sk_status == False:
        print("This skill does not exist.\n")
        return False, '', '', '', []
    try:
        alert = re.findall(RE_DIC['alert'], sk_resp.text)[0]
        alert = toValidStr(alert)
        if "This skill is not currently available." in alert:
            return False, '', '', '', []
    except:
        pass
    title = re.findall(RE_DIC['title'], sk_resp.text)[0]
    title = toValidStr(title)
    descr = ''
    invocation = ''
    try:
        descr = re.findall(RE_DIC['description'], sk_resp.text)[0]
        descr = toValidStr(descr)
        invocation = re.findall(RE_DIC['invocation'], sk_resp.text)[0]
        invocation = toValidStr(invocation)
    except:
        return False, '', '', '', []
    pers = []
    try:
        permissions = re.findall(RE_DIC['permissions'], sk_resp.text, re.S)[0]
        pers = re.findall(RE_DIC['perm'], permissions)
    except:
        pers = []
    return True, title, descr, invocation, pers
        
def getURL(url):
    resp = requests.get(url,headers=USER_AGENT)
    resp.encoding = resp.apparent_encoding
    if resp.status_code == 200:
        titles = re.findall(RE_DIC['tit'], resp.text)
        if len(titles) > 0 and 'Page Not Found' in titles[0]:
            print(titles[0])
            return None, False
        return resp, True
    return None, False

def toValidStr(string):
    string = html.unescape(string)
    string = string.encode(encoding='utf-8', errors = 'ignore').decode(encoding='utf-8')
    string = string.replace("‘", '\'')
    string = string.replace("’", '\'')
    string = string.replace("”", '\"')
    string = string.replace("“", '\"')
    string = string.replace("<br/>", '')
    string = string.replace("\n", '')
    return string

