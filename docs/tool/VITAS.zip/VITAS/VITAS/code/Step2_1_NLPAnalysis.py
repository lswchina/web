import spacy
import sys
import re
import openpyxl
from selenium import webdriver
from selenium.webdriver.support import expected_conditions
import time
import html
import copy
import Step1_GetDocument as docu

M = 10

def splitSentence(Line):
    Line = toValidStr(Line)
    Lines = Line.split("<Short audio>.")
    clauses = []
    for line in Lines:
        nlp = spacy.load("en_core_web_sm")
        doc = nlp(line)
        clause = ""
        inQuotes = False
        tempclauses = []
        for i in range(len(doc)):
            #print(doc[i].text, getTokenPos(doc[i]), getTokenDep(doc[i]))
            if getTokenPos(doc[i]) == "PUNCT":
                if doc[i].text == '.' or doc[i].text == '!' or doc[i].text == '?':
                    if inQuotes == False:
                        if clause != "":
                            tempclauses.append(clause)
                            clause = ""
                    else:
                        clause = clause + doc[i].text
                elif '.' in doc[i].text  or '!' in doc[i].text or '?' in doc[i].text:
                    if '.' in doc[i].text:
                        position = str(doc[i].text).index('.')
                    elif '!' in doc[i].text:
                        position = str(doc[i].text).index('!')
                    else:
                        position = str(doc[i].text).index('?')
                    if clause == "":
                        clause = str(doc[i].text)[: position]
                    else:
                        clause = clause + " " + str(doc[i].text)[: position]
                    tempclauses.append(clause)
                    clause = str(doc[i].text)[position + 1:]
                elif doc[i].text == "\"":
                    if inQuotes == True:
                        inQuotes = False
                    else:
                        inQuotes = True
                    if clause == "":
                        clause = doc[i].text
                    else:
                        clause = clause + " " + doc[i].text
                else:
                    clause = clause + doc[i].text
            elif getTokenPos(doc[i]) != "SPACE":
                if clause != "":
                    clause = clause + " " + doc[i].text
                else:
                    if str(doc[i].text)[0] >= 'a' and str(doc[i].text)[0] <= 'z':
                        if len(tempclauses) > 0:
                            clause = tempclauses.pop()
                            clause = clause + " " + doc[i].text
                        else:
                            clause = clause + doc[i].text
                    else:
                        clause = clause + doc[i].text
        if clause != "":
            tempclauses.append(clause)
        tempclauses.append("<Short audio>")
        clauses.extend(tempclauses)
    if len(clauses) == 0:
        clauses.append(" ")
    else:
        clauses.pop()
    return clauses

def getTokenPos(token):
    if type(token) == spacy.tokens.span.Span:
        return token.root.pos_
    return token.pos_
    
def getTokenDep(token):
    if type(token) == spacy.tokens.span.Span:
        return token.root.dep_
    return token.dep_

def getTokenHead(token):
    if type(token) == spacy.tokens.span.Span:
        return token.root.head
    return token.head

def toValidStr(string):
    string = html.unescape(string)
    string = string.encode(encoding='utf-8', errors = 'ignore').decode(encoding='utf-8')
    string = string.replace("‘", '\'')
    string = string.replace("’", '\'')
    string = string.replace("”", '\"')
    string = string.replace("“", '\"')
    text = re.compile(u"[\s\w\.'!?,<>]").findall(string)
    string = "".join(text)
    return string

class Skill:
    '''def __init__(self, description):
        self.invocation = []
        self.skillName = ''
        self.skillActions = []
        self.userActions = []
        self.otherActions = []
        self.basicComds = {}
        self.clauses = []
        self.spacyRets = []
        self.parseDocu(description)
        self.imergeNouns()
        self.parse()
        self.getInfoInQuotes()
        self.getBascComds()
        self.getSysComds()'''

    def __init__(self, excelfilename, line):
        self.invocation = []
        self.skillName = ''
        self.supportRegion = False
        self.skillActions = []#skill functionality
        self.userActions = []
        self.otherActions = []
        self.basicComds = {}#document-retrieved commands
        self.sysComds = {}#system-level commands
        self.clauses = []
        self.spacyRets = []
        self.parseExcel(excelfilename, line)
        if self.skillName != '' and self.skillName != '<end_of_excel>':
            self.imergeNouns()
            self.parse()
            self.getInfoInQuotes()
            self.getBascComds()
            self.getSysComds()

    def parseDocu(self, description):
        self.clauses = splitSentence(description)
    
    def parseExcel(self, excelfilename, line):
        excel = openpyxl.load_workbook(excelfilename)
        sheet = excel.worksheets[0]
        if line >= sheet.max_column:
            self.skillName = '<end_of_excel>'
            return
        skillAttri = list(sheet.rows)[line]
        if 'my Flash Briefing' in str(skillAttri[5].value):
            return
        res = docu.getSkillWeb(str(skillAttri[1].value)) #is available skill?
        if res[0] == False:
            return
        for c in range(12, sheet.max_column):
            lan = str(skillAttri[c].value)
            if lan == None:
                break
            else:
                if 'AU' in lan:
                    self.supportRegion = True
                    break
        self.skillName = res[1]
        self.clauses = splitSentence(res[2])
        self.invocation = ["Alexa, open " + res[3]]
        self.permission_list = res[4]

    def imergeNouns(self):
        nlp = spacy.load("en_core_web_sm")
        for i, clause in enumerate(self.clauses):
            doc = nlp(clause)
            words = []
            for word in doc:
                words.append(word)
            for chunk in doc.noun_chunks:
                chunk_text = str(chunk.text).replace(" ", "")
                begin = 0
                isEqual = False
                words_left = -1
                words_right = -1
                for j in range(len(words)):
                    length = len(words[j].text)
                    if begin + length > len(chunk_text):
                        words_right = j
                        break
                    elif words[j].text == chunk_text[begin: begin + length]:
                        if isEqual == False:
                            words_left = j
                            isEqual = True
                        begin = begin + length
                    else:
                        isEqual = False
                        begin = 0
                        words_left = -1
                        words_right = -1
                if words_left >= 0:
                    if words_right == -1:
                        words_right = len(words)
                    del words[words_left: words_right]
                    words.insert(words_left, chunk)
            self.spacyRets.append(words)
    
    def findSubjectType(self, subjects):#0:skill 1:user 2:other
        skillSim = 0
        userSim = 0
        nlp = spacy.load("en_core_web_md")
        if type(subjects) == spacy.tokens.span.Span:
            subject = nlp(subjects.root.text)
        else:
            subject = nlp(subjects.text)
        if subject[0].lemma_ == "which" or subject[0].lemma_ == "who" or subject[0].lemma_ == "it":
            return self.subjectType
        for i, skilln in enumerate(nlp(self.skillName)):
            if subject[0].similarity(skilln) > skillSim:
                skillSim = subject[0].similarity(skilln)
        skill = nlp("skill")
        if subject[0].similarity(skill[0]) > skillSim:
            skillSim = subject[0].similarity(skill[0])
        alexa = nlp("alexa")
        if subject[0].similarity(alexa[0]) > skillSim:
            skillSim = subject[0].similarity(alexa[0])
        we = nlp("we")
        if subject[0].similarity(we[0]) > skillSim:
            skillSim = subject[0].similarity(we[0])
        
        user = nlp("user")
        if subject[0].similarity(user[0]) > userSim:
            userSim = subject[0].similarity(user[0])
        you = nlp("you")
        if subject[0].similarity(you[0]) > userSim:
            userSim = subject[0].similarity(you[0])
        
        if userSim <= 0.8 and skillSim <= 0.8:
            return 2
        elif userSim > skillSim:
            return 1
        else:
            return 0

    def addAction(self, action):
        if len(action) == 1 and (action[0].lemma_ == "can" or action[0].lemma_ == "will"):
            return
        if self.subjectType == 0:
            IsAdd = True
            for i, skillAction in enumerate(self.skillActions):
                if len(skillAction) == len(action):
                    for j in range(len(action)):
                        if action[j].lemma_ != skillAction[j].lemma_:
                            break
                    if j == len(action) - 1 and action[j].lemma_ == skillAction[j].lemma_:
                        IsAdd = False
                        break
            if IsAdd == True:
                self.skillActions.append(action)
        elif self.subjectType == 1:
            IsAdd = True
            for i, userAction in enumerate(self.userActions):
                if len(userAction) == len(action):
                    for j in range(len(action)):
                        if action[j].lemma_ != userAction[j].lemma_:
                            break
                    if j == len(action) - 1 and action[j].lemma_ == userAction[j].lemma_:
                        IsAdd = False
                        break
            if IsAdd == True:
                self.userActions.append(action)
        elif self.subjectType == 2:
            IsAdd = True
            for i, otherAction in enumerate(self.otherActions):
                if len(otherAction) == len(action):
                    for j in range(len(action)):
                        if action[j].lemma_ != otherAction[j].lemma_:
                            break
                    if j == len(action) - 1 and action[j].lemma_ == otherAction[j].lemma_:
                        IsAdd = False
                        break
            if IsAdd == True:
                self.otherActions.append(action)
        else:
            print("no subject?")
            sys.exit()
    
    def parse(self):
        self.subjectType = 2
        for i, clause in enumerate(self.spacyRets):
            state = 0
            action = [] #record the actions
            for j, word in enumerate(clause):
                if getTokenDep(word) == 'nsubj' or getTokenDep(word) == 'nsubjpass':
                    if getTokenDep(word) == 'nsubjpass':
                        self.subjectType = 0
                        action.append(word)
                    else:
                        self.subjectType = self.findSubjectType(word)
                    j = j + 1
                    state = 1
                    break
                elif getTokenDep(word) == 'expl':
                    self.subjectType = 0 #subject: this skill
                    j = j + 1
                    state = 1
                    break
            if state == 0: #state: no subject
                self.subjectType = 1 #subject: you
                state = 1
                j = 0
            while j < len(clause):
                if state == 1:#state: find subject, to find verb/aux
                    if getTokenPos(clause[j]) == 'VERB':
                        if getTokenDep(clause[j]) != 'amod' and clause[j].lemma_ != 'can' and clause[j].lemma_ != 'need' and clause[j].lemma_ != 'will':
                            action.append(clause[j])
                            state = 2
                    elif getTokenPos(clause[j]) == 'AUX':
                        action.append(clause[j])
                        if getTokenDep(clause[j]) != 'auxpass':
                            state = 3
                    elif getTokenDep(clause[j]) == 'nsubj' or getTokenDep(clause[j]) == 'nsubjpass':#another subject
                        if len(action) != 0:
                            self.addAction(action)
                            action = []
                        if getTokenDep(clause[j]) == 'nsubjpass':
                            self.subjectType = 0
                            action.append(clause[j])
                        else:
                            self.subjectType = self.findSubjectType(clause[j])
                elif state == 2: #state: find verb, to find prep/noun
                    if (getTokenPos(clause[j]) == 'VERB' and getTokenDep(clause[j]) != 'amod') or getTokenPos(clause[j]) == 'AUX':
                        if j > 0 and getTokenPos(clause[j - 1]) == 'PART':
                            state = 1
                            continue
                        else:
                            if len(action) != 0:
                                self.addAction(action)
                                action = []
                            state = 1
                            continue
                    elif getTokenDep(clause[j]) == 'nsubj' or getTokenDep(clause[j]) == 'nsubjpass':#another subject
                        if len(action) != 0:
                            self.addAction(action)
                            action = []
                        if getTokenDep(clause[j]) == 'nsubjpass':
                            self.subjectType = 0
                            action.append(clause[j])
                        else:
                            self.subjectType = self.findSubjectType(clause[j])
                        state = 1
                    elif getTokenPos(clause[j]) == 'NOUN' or getTokenPos(clause[j]) == 'PROPN':
                        action.append(clause[j])
                    elif getTokenDep(clause[j]) == 'prep':
                        action.append(clause[j])
                    elif getTokenPos(clause[j]) == 'PART':
                        action.append(clause[j])
                elif state == 3:#find aux, to find prep/noun/adj
                    if (getTokenPos(clause[j]) == 'VERB' and getTokenDep(clause[j]) != 'amod') or getTokenPos(clause[j]) == 'AUX':
                        if j > 0 and (getTokenPos(clause[j - 1]) == 'PART' or getTokenPos(clause[j - 1]) == 'AUX'):
                            state = 1
                            continue
                        else:
                            if len(action) != 0:
                                self.addAction(action)
                                action = []
                            state = 1
                            continue
                    elif getTokenDep(clause[j]) == 'nsubj' or getTokenDep(clause[j]) == 'nsubjpass':#another subject
                        if len(action) != 0:
                            self.addAction(action)
                            action = []
                        if getTokenDep(clause[j]) == 'nsubjpass':
                            self.subjectType = 0
                            action.append(clause[j])
                        else:
                            self.subjectType = self.findSubjectType(clause[j])
                        state = 1
                    elif getTokenPos(clause[j]) == 'NOUN' or getTokenPos(clause[j]) == 'PROPN':
                        action.append(clause[j])
                    elif getTokenDep(clause[j]) == 'prep':
                        action.append(clause[j])
                    elif getTokenPos(clause[j]) == 'PART':
                        action.append(clause[j])
                    elif getTokenPos(clause[j]) == 'ADJ':
                        action.append(clause[j])
                j = j + 1
            if len(action) != 0:
                self.addAction(action)

    def getInfoInQuotes(self):
        self.infoInQuotes = []
        inInfo = False
        impInfo = ''
        for i, clause in enumerate(self.clauses):
            nlp = spacy.load("en_core_web_sm")
            doc = nlp(clause)
            for word in doc:
                if "\"" in word.text:
                    if inInfo == False:
                        inInfo = True
                    else:
                        inInfo = False
                        if 'Alexa' not in impInfo and 'alexa' not in impInfo:
                            self.infoInQuotes.append(impInfo)
                        impInfo = ''
                else:
                    if inInfo == True:
                        if impInfo == '':
                            impInfo = re.sub(r"[^\sa-zA-Z0-9_\.,'?!]", '', word.text)
                        else:
                            impInfo = impInfo + ' ' + re.sub(r"[^\sa-zA-Z0-9_\.,'?!]", '', word.text)
        print(self.infoInQuotes)
        return self.infoInQuotes
  
    def getInitWeight(self, userAct):
        length = len(userAct)
        impActWord = ['get', 'help', 'change', 'repeat', 'set', 'collect', 'play']#instruction verbs
        weight = 0
        nlp = spacy.load("en_core_web_md")
        
        verb = nlp(userAct[0].text)[0]
        
        for word in impActWord:
            ImpW = nlp(word)[0]
            if ImpW.similarity(verb) > weight:
                weight = ImpW.similarity(verb)
        if weight > 1.0:
            weight = 1.0
        return weight

    def getBascComds(self):
        for i in range(len(self.userActions)):
            if len(self.userActions[i]) > 0 and self.userActions[i][0].lemma_ == "be" or len(self.userActions[i]) == 0:
                continue
            bascComd = []
            bascComdContent = ""
            for j in range(len(self.userActions[i])):
                if bascComdContent == "":
                    bascComdContent = re.sub(r"[^\sa-zA-Z0-9_\.,'?!]", '', self.userActions[i][j].text)
                else:
                    bascComdContent = bascComdContent + " " + re.sub(r"[^\sa-zA-Z0-9_\.,'?!]", '', self.userActions[i][j].text)
            bascComdRltWeight = self.getInitWeight(self.userActions[i])
            bascComd = [M, 0, bascComdRltWeight]
            self.basicComds[bascComdContent] = bascComd
            
        for i in range(len(self.infoInQuotes)):
            bascComd = [M, 0, 0.8]
            self.basicComds[self.infoInQuotes[i]] = bascComd
        return self.basicComds
              
    def getSysComds(self):
        sysword = ['Pause', 'Resume', 'Restart', 'Reboot', 'Stop', 'Exit', 'Cancel', 'What\'s the time']
        for sw in sysword:
            sysAnr = [M, 0, 0.1]
            self.sysComds[sw] = copy.deepcopy(sysAnr)
        return self.sysComds
